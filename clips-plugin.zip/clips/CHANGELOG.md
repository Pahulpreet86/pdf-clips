# Changelog

## 1.2.0

- Renamed the plugin to **Clips**.
- Security hardening: all PDF-derived text (title, author, publisher, highlights,
  notes) is now Markdown-escaped on output, so a crafted PDF can't inject links,
  images, or raw HTML into your notes. Ordinary prose punctuation is left alone,
  so normal highlights stay readable.
- Pinned the PyMuPDF dependency (`pymupdf==1.24.10`) instead of installing latest,
  and documented that parsing untrusted PDFs is the real attack surface — keep the
  parser updated and sandbox untrusted files.

## 1.1.0

- New output format: a header block (`# Title`, `**Author:**`, `**Publisher:**`,
  `**Published:**`), a `---` rule, then `##` headings with plain `- ` bullets.
- Reads title/author/publisher/year from the PDF's standard metadata and XMP
  (`dc:publisher`, `dc:date`); missing fields render as `Unknown`.
- New flags: `--title`, `--author`, `--publisher`, `--year` to override the header,
  and `--notes inline|skip` to append or drop sticky-note comments.
- Headings are now flat (`##`) to match the requested format.

## 1.0.0

- Initial release.
- `extract-highlights` skill: pulls highlight / underline / strikeout / squiggly
  annotations and sticky-note comments from an annotated PDF.
- Recovers highlighted text from annotation quad points.
- Groups highlights under chapter/section headings from the PDF outline; resolves
  same-page heading order by locating heading text; falls back to per-page grouping
  when the PDF has no outline; puts pre-chapter highlights under "Front matter".
- Outputs a Markdown file with blockquoted passages, notes, page numbers, and
  highlight colors.
